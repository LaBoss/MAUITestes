namespace PrismBug;

public partial class Setting : ContentPage
{
	public Setting()
	{
		InitializeComponent();
	}
}