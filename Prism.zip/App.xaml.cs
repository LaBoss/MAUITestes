﻿namespace PrismBug
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }
    }
}